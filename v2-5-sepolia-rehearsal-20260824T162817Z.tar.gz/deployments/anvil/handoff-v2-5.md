# Wildcat v2-5 handoff: anvil

Chain ID: `31337`. Generated: `2026-08-24T16:24:27.742Z`.

## Factory indexing

| Label | Kind | Market type | Address | Start block | Lifecycle | Index all | ABI artifact |
| --- | --- | --- | --- | ---: | --- | --- | --- |
| legacy-v2 | hooks-factory | legacy | `0xE3e4B7C9E0Ab4ccbC70e0583Dca7B4Db9B4CFD88` | 6973842 | live | yes | `src/IHooksFactory.sol:IHooksFactory` |
| standard-v2-1 | hooks-factory | legacy | `0x10A64ABa0159720F8a23E1A552800CA4eb21576C` | 7124440 | live | yes | `src/IHooksFactory.sol:IHooksFactory` |
| revolving-sepolia-20260419-233246 | hooks-factory | revolving | `0xF4564015E524cf5629828E61F45ed339D998D85f` | 10695521 | retired | no | `src/IHooksFactoryRevolving.sol:IHooksFactoryRevolving` |
| revolving-sepolia-20260424-140119 | hooks-factory | revolving | `0xb899ba2a5F5b609898A2bABe445Aa31dDf0277e5` | 10725492 | live | yes | `src/IHooksFactoryRevolving.sol:IHooksFactoryRevolving` |
| standard-v2-5-preview-20260727 | hooks-factory | legacy | `0xAa9BbaE0D519e85B6aBEA81aD3C2cBeBfA57696C` | 11363908 | live | yes | `src/IHooksFactory.sol:IHooksFactory` |
| revolving-v2-5-preview-20260727 | hooks-factory | revolving | `0x76Fe050d91940a72133e1819BF34c1042d8DBe73` | 11363912 | live | yes | `src/IHooksFactoryRevolving.sol:IHooksFactoryRevolving` |
| legacy-test-2024-08-05 | hooks-factory | legacy | `0x6Cb3512b541733d340Aa520b63105586588BD600` | 6443857 | retired | no | `src/IHooksFactory.sol:IHooksFactory` |
| legacy-test-2024-09-23 | hooks-factory | legacy | `0xE1d14E8176d27415c204A4F9Ef58E107964CA12C` | 6746262 | retired | no | `src/IHooksFactory.sol:IHooksFactory` |
| legacy-test-2024-11-21 | hooks-factory | legacy | `0xCf872Ac862d2ba97F99804ed25f0dB5F2352933a` | 7123486 | retired | no | `src/IHooksFactory.sol:IHooksFactory` |
| HooksFactory_v2-5 | hooks-factory | legacy | `0xbFbDaFc91977eE599a61B30D9e75788565Ad6d18` | 11558159 | canonical | yes | `src/IHooksFactory.sol:IHooksFactory` |
| HooksFactoryRevolving_v2-5 | hooks-factory | revolving | `0x190B42942fe9492df9CeA441dA5c43309840E93A` | 11558161 | canonical | yes | `src/IHooksFactoryRevolving.sol:IHooksFactoryRevolving` |
| wrapper-v1 | wrapper-factory | - | `0x0566Fe57682164af689f1440cb3BCEedEe3bf843` | 10534112 | live | yes | `src/vault/Wildcat4626WrapperFactory.sol:IWildcat4626WrapperFactoryV1` |
| Wildcat4626WrapperFactory_v2-5 | wrapper-factory | - | `0x6B1DD93453584346C530A1646e98aB306fD6D37C` | 11558155 | canonical | yes | `src/vault/Wildcat4626WrapperFactory.sol:Wildcat4626WrapperFactory` |

## Routing

- Use canonical lifecycle records for new deployments and SDK routing. Continue indexing every generation with indexAll=true. Do not index records with indexAll=false; they remain in the append-only inventory.
- 4626: The canonical v2.5 facade serves locally recorded v2.5 floor-rounding markets. Markets without scaledTransferRounding() fall through to v1Factory when configured. Markets declaring an unsupported rounding do not fall through.
- Lens: Treat MarketLens as the public facade. It static-calls the core, aggregation, or live helper selected by the requested method; helper addresses are implementation contracts, not replacement facade addresses.
- Lifecycle: Canonical means the generation selected for new deployments and current aliases. Live means an older generation that remains indexed for its existing markets. Retired generations stay recorded but are excluded from indexing.

## Release contracts

| Deployment key | Kind | Address | Start block | ABI artifact |
| --- | --- | --- | ---: | --- |
| WildcatBorrowerIdentityRegistry_v2-5 | borrower-identity-registry | `0xc2cF90781595203D1e75c28246b306C95d4b8b21` | 11558156 | `src/interfaces/IBorrowerIdentityRegistry.sol:IBorrowerIdentityRegistry` |
| AccessListRoleProviderFactory_v2-5 | role-provider-factory | `0x92995EA2ba572E4Cb8bB41E30f813BeB77FD4974` | 11558157 | `src/providers/IAccessListRoleProviderFactory.sol:IAccessListRoleProviderFactory` |
| WildcatMarket_initCodeStorage_v2-5 | market-init-code-storage | `0xED41382959e50dc3B65d0684B444F1BcC71465e8` | 11558158 | `src/market/WildcatMarket.sol:WildcatMarket` |
| HooksFactory_v2-5 | hooks-factory | `0xbFbDaFc91977eE599a61B30D9e75788565Ad6d18` | 11558159 | `src/IHooksFactory.sol:IHooksFactory` |
| WildcatMarketRevolving_initCodeStorage_v2-5 | market-init-code-storage | `0x56B4E1A4161Decf4224cB16B037f2696698dBa34` | 11558160 | `src/market/WildcatMarketRevolving.sol:WildcatMarketRevolving` |
| HooksFactoryRevolving_v2-5 | hooks-factory | `0x190B42942fe9492df9CeA441dA5c43309840E93A` | 11558161 | `src/IHooksFactoryRevolving.sol:IHooksFactoryRevolving` |
| MarketLensCore_v2-5 | lens-helper-core | `0xa5a01A1d9B1BfB0B0a4A245e63115b1f3523fC8b` | 11558162 | `src/lens/MarketLensCore.sol:MarketLensCore` |
| MarketLensAggregator_v2-5 | lens-helper-aggregator | `0xB48f6f86451301a87f61c00f5d1800C7BeA9D44D` | 11558163 | `src/lens/MarketLensAggregator.sol:MarketLensAggregator` |
| MarketLensLive_v2-5 | lens-helper-live | `0xD99f39953A54C416F8FfEeD2B79E5D848582ba0c` | 11558164 | `src/lens/MarketLensLive.sol:MarketLensLive` |
| MarketLens_v2-5 | lens-facade | `0xcFc66c78CF7518A1378d751e1C3526eEad25A31A` | 11558165 | `src/lens/MarketLens.sol:MarketLens` |
| Wildcat4626WrapperFactory_v2-5 | wrapper-factory | `0x6B1DD93453584346C530A1646e98aB306fD6D37C` | 11558155 | `src/vault/Wildcat4626WrapperFactory.sol:Wildcat4626WrapperFactory` |
| OpenTermHooks_initCodeStorage_v2-5 | hooks-template-init-code-storage | `0x1840E97Fba22DbA0996f4b8D02fc8bB74473dD95` | 11558166 | `src/access/OpenTermHooks.sol:OpenTermHooks` |
| FixedTermHooks_initCodeStorage_v2-5 | hooks-template-init-code-storage | `0x7Cf683E0802257180EDf4C21A12C5070acd166d2` | 11558167 | `src/access/FixedTermHooks.sol:FixedTermHooks` |
| PeriodicTermHooks_initCodeStorage_v2-5 | hooks-template-init-code-storage | `0xB63929E732156C46857C0d9b08e483f8845Ed1BE` | 11558168 | `src/access/PeriodicTermHooks.sol:PeriodicTermHooks` |

## ABI changes since deployed v2

### WildcatMarket and WildcatMarketRevolving

- Changed: version() return value changed from '2' to '2.5'.
- Added: borrower(), borrowerPrincipal(), borrowerIdentityRegistry(), pendingBorrower(), pendingBorrowerPrincipal(), requestBorrowerTransfer(address), cancelBorrowerTransfer(), and acceptBorrowerTransfer().
- Added: wrapperFactory(), registerWrapper(address), and registeredWrapper().
- Added: WrapperRegistered(address) event plus NotWrapperFactory, WrapperAlreadyRegistered, and CannotNukeWrapper errors.
- Added: queueWithdrawalScaled(uint256) queues an exact scaled withdrawal amount.
- Added: scaledTransferRounding() returns keccak256('scaleAmountDown').
- Added: executePendingAnnualInterestBipsReduction() applies a matured hooks proposal.
- Added: AprReductionNotReduction error.
- Added: ExecutePendingAprReductionNotEnabled error.
- Added: WithdrawalBatchKeyAlreadyExists error.
- Removed: NullBuyBackAmount and BuyBackOnDelinquentMarket errors.

### Borrower identity registry

- Added: Principal resolution for direct borrowers and borrower accounts.
- Added: Account-factory registration and account-to-principal association events.
- Added: Two-step borrower-account principal transfers.

### Access-list role-provider factory

- Added: Permissionless deterministic deployment of borrower-administered access-list providers.
- Added: Two-step provider administrator transfers and enumerable membership management.

### HooksFactory and HooksFactoryRevolving

- Changed: HooksTemplateAdded, HooksTemplateDisabled, and HooksTemplateFeesUpdated identify the caller and preserve complete fee history.
- Changed: HooksInstanceDeployed identifies the template, administrator, deployer, name, and version.
- Changed: MarketDeployed identifies borrower, principal, identity registry, requested hooks, and accepted hooks; configuration and hook payload move to companion events.
- Changed: getMarketParameters() includes the borrower identity registry and wrapper factory.
- Added: HooksInstanceRoleProviders, HooksInstanceAdministratorTransferred, MarketDeploymentConfig, MarketHooksData, and RevolvingMarketDeployed events.
- Added: borrowerIdentityRegistry(), wrapperFactory(), hook-administrator indexing, and administrator-transfer callback views.

### PeriodicTermHooks

- Added: AnnualInterestBipsReductionProposed event.
- Added: AnnualInterestBipsReductionProposalCancelled event.
- Added: AnnualInterestBipsReductionExecuted event.
- Added: AprReductionProposalDuringWithdrawalWindow error.
- Added: AprReductionProposalNotReduction error.
- Added: NoPendingAprChange error.
- Added: AprChangeDoesNotMatchProposal error.
- Added: AprChangeNotReady error.
- Added: AprReductionProposalExpired error.
- Added: AprReductionProposalOnClosedMarket error.
- Added: UnpaidWithdrawalsExist error.
- Added: templateVersion() returns 2; version() remains 'PeriodicTermHooks'.
- Added: pendingAprChanges(address), getHookedMarket(address), getHookedMarkets(address[]), isWithdrawalWindowOpen(address), and getPendingAprChange(address) views.

### Access-control hook templates

- Added: administrator(), pendingAdministrator(), requestAdministratorTransfer(address), cancelAdministratorTransfer(), and acceptAdministratorTransfer().
- Added: AdministratorTransferRequested, AdministratorTransferCancelled, and AdministratorTransferred events.
- Added: RoleProviderAdded, RoleProviderUpdated, and RoleProviderRemoved carry administrator, TTL, and complete pull/push index history.
- Added: AccountAccessGranted and AccountAccessRevoked identify provider, account, and caller.
- Added: NameUpdated, MinimumDepositUpdated, FixedTermUpdated, and PeriodicTermUpdated carry actor plus previous/new state where applicable.
- Added: isMarketTransferDisabled(address) reports the immutable per-market transfer policy.
- Added: DepositHookNotEnabled error.

### MarketLens

- Changed: HooksConfigData return tuples append useOnExecutePendingAnnualInterestBipsReduction; consumers must regenerate ABI tuple decoders.
- Added: Borrower, principal, pending borrower, hook administrator, provider administration, transfer policy, wrapper, and revolving-credit state in the v2.5 market and hooks views.
- Added: Core, aggregation, and live helper routing behind the MarketLens facade.

### Wildcat4626WrapperFactory

- Added: v1Factory(), wrapperForMarket(address), createWrapper(address), isFloorRoundingMarket(address), and WrapperDeployed(address,address).
- Added: WrapperAlreadyExists, LegacyMarketsNotSupported, UnsupportedMarketRounding, NotRegisteredMarket, InvalidV1Factory, and ZeroAddress errors.
- Added: MarketTransfersDisabled(address) error.
- Added: UnsupportedMarketTransferPolicy(address,address) error.

### WildcatMarketRevolving

- Added: commitmentFeeBips() view.
- Added: drawnAmount() view.
- Added: DrawnAmountUpdated(uint256,uint256) event.

### Market event surface

- Changed: MaxTotalSupplyUpdated, ProtocolFeeBipsUpdated, Borrow, MarketClosed, and FeesCollected identify the acting borrower, caller, collector, or fee recipient and preserve previous/new values where applicable.
- Changed: AnnualInterestBipsUpdated and ReserveRatioBipsUpdated are replaced by the atomic AnnualInterestAndReserveRatioBipsUpdated event.
- Added: BorrowerTransferRequested, BorrowerTransferCancelled, and BorrowerTransferred events preserve operational borrower and principal history.
- Added: WrapperRegistered(address) event.
- Removed: AccountSanctioned event.
- Removed: SanctionedAccountAssetsSentToEscrow event.
