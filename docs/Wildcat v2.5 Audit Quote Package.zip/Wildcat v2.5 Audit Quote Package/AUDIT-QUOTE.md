# Wildcat V2.5 audit quote

Prepared 2026-10-05.

**Scope: 100 Solidity files, 10,498 normalized source lines of code (nSLOC).**
We're requesting a quote for a full review of the included source.

## Source and size

| Field | Value |
| --- | --- |
| Repository | [`wildcat-finance/v2-protocol`](https://github.com/wildcat-finance/v2-protocol) |
| Audit branch | <https://github.com/wildcat-finance/v2-protocol/tree/audit/v2.5> |
| Complete audit-package commit | [`529f2db55d656b89db4b17ecf6685b7589d5d7dd`](https://github.com/wildcat-finance/v2-protocol/tree/529f2db55d656b89db4b17ecf6685b7589d5d7dd) |
| Included source | 99 files under `src/`, plus `script/common/PreparedInitCodeStorage.sol` |
| Normalized SLoC | 10,498 |
| Physical SLoC | 13,103 |

Counts include interfaces and shared code, exclude comments and blank lines,
and use `solidity-code-metrics@0.0.28`.
Its normalized count collapses function signatures. The
[manifest](evidence/source-manifest.json)
lists every included file and its hash.
Retained contract source is unchanged from release commit
`bfe1412141f263ba6b056c60c3f4654a461598dd`.

V2.5 retains substantial V2.1 code: after presentation normalization, 342 of
the baseline's 588 explicit function/modifier definitions with bodies remain
unchanged at their original locations. Separately, 23 files totaling 1,137
current nSLOC have unchanged declarations, including `WildcatArchController`
and the SphereX sources. The [V2.1-to-V2.5 comparison](V2.1-TO-V2.5.md)
distinguishes reuse, refactoring, and substantive changes. These are source-reuse
counts, not audit-effort estimates; the full scope remains included.

## Scope

Review all remaining `src/**/*.sol` files on the audit branch and the prepared
creation-code installation constructors listed above. This includes standard
and revolving markets, accounting and withdrawal settlement, repayment and
default, factories, term hooks, borrower identity, sanctions, SphereX integration,
ERC-4626 wrappers, lenses, libraries, and interfaces.

```text
src/
├── *.sol       # Factories, controller, identity, sanctions, reentrancy
├── market/     # Standard/revolving markets, configuration, withdrawals
├── access/     # Hooks, term policies, access control, provider integration
├── providers/  # AccessList provider, factory, shared base, interfaces
├── vault/      # ERC-4626 wrapper and factory
├── lens/       # Aggregated and live read surfaces
├── libraries/  # Accounting, math, queues, creation-code readers
├── types/      # Hook configuration, credentials, transient data
├── interfaces/ # Shared contract interfaces, events, errors, structs
└── spherex/    # SphereX configuration and protection integration
script/common/PreparedInitCodeStorage.sol  # Installation constructors
```

Role-provider scope is `AccessListRoleProvider.sol`,
`AccessListRoleProviderFactory.sol`, the shared `ManagedRoleProvider.sol` base,
and their interfaces. Other provider implementations and their dedicated
factories/interfaces are excluded and
removed from the audit branch. Shared provider interfaces, hook integration,
and lens behavior remain in scope. The ERC-4626 wrapper is included; the
ERC-4626-assets credential provider is excluded.

Third-party library implementations under `lib/` are excluded from a standalone
dependency audit; Wildcat's use of them and its external-call boundaries remain
in scope. Tests and documentation support the review. Deployment tooling and
ceremonies, address verification, SDK, frontend, subgraph, keepers, and external
sanctions/SphereX services are outside this quote.

## Context for reviewers

Wildcat provides undercollateralized credit. Borrower default and actions within
documented borrower authority are credit risk; broken accounting or exceeded
authority are security concerns. Review priorities are:

- Scaled balances, interest, revolving commitment fees, rounding, and withdrawal
  allocation; repayment deadlines, default records, closure, and surplus.
- Hook and provider permissions, borrower transfers, callback failures and
  reentrancy; deterministic deployment and creation-code integrity.
- Wrapper share backing, generation routing, recipient policy, sanctions escrow,
  and agreement between lens results and executable behavior.

Underlying lending assets are expected to have conventional, stable ERC-20
behavior. Market tokens rebase; wrapper shares do not. There is no price oracle,
AMM, bridge, or cross-chain messaging. Sanctions checks depend on an external
list. Intended targets are Ethereum and Plasma, with independent deployments
requiring Cancun/EIP-1153 support.

The [technical scope](SCOPE.md),
[security assumptions](https://github.com/wildcat-finance/v2-protocol/blob/529f2db55d656b89db4b17ecf6685b7589d5d7dd/docs/security/assumptions.md), and
[known limitations](https://github.com/wildcat-finance/v2-protocol/blob/529f2db55d656b89db4b17ecf6685b7589d5d7dd/docs/security/known-issues.md)
supply the detailed boundaries.
Prior reviews are indexed in [`audits/`](https://github.com/wildcat-finance/v2-protocol/blob/529f2db55d656b89db4b17ecf6685b7589d5d7dd/audits/README.md). This review
covers the full included source, including reused contracts. Four periodic-term
timing constants remain marked `TODO FOR MAINNET`; any changes require a review
delta.

## Tests and quote terms

The audit package passed 907 reported tests across 85 suites, including
three invariant campaigns, with no failures or skips. It uses Foundry 1.8.3,
Solidity 0.8.25, Cancun, via IR, and the pinned runs-1 optimizer configuration.
The [test guide](https://github.com/wildcat-finance/v2-protocol/blob/529f2db55d656b89db4b17ecf6685b7589d5d7dd/TESTS.md)
covers setup and focused runs; no RPC or wallet is needed for the canonical suite.

The [verification receipt](evidence/verification.json)
records the checks.
Coverage is partial because some instrumented builds hit compiler limits;
SphereX coverage uses a temporary patch. Static analysis needs the qualified
Slither fork linked in the [suite guide](https://github.com/wildcat-finance/v2-protocol/blob/529f2db55d656b89db4b17ecf6685b7589d5d7dd/test/README.md#static-analysis).

Please include price, earliest start, expected duration and reviewer allocation,
report deliverables, and the fix-review allowance in your quote.
