# Wildcat v2.5 Audit Quote Package

Start with the [audit quote](AUDIT-QUOTE.md). It defines the requested
scope, size, review context, and quote terms: 100 Solidity files and 10,498
normalized source lines of code (nSLOC).

The contracts, tests, dependencies, and build instructions are in the repository.
Use the exact commit below for the quote and source review.

Audit branch:
<https://github.com/wildcat-finance/v2-protocol/tree/audit/v2.5>

Quoted source commit:
<https://github.com/wildcat-finance/v2-protocol/tree/529f2db55d656b89db4b17ecf6685b7589d5d7dd>

To check out that source:

```sh
git clone --branch audit/v2.5 https://github.com/wildcat-finance/v2-protocol.git
cd v2-protocol
git checkout --detach 529f2db55d656b89db4b17ecf6685b7589d5d7dd
git submodule update --init --recursive
```

The repository's [README](https://github.com/wildcat-finance/v2-protocol/blob/529f2db55d656b89db4b17ecf6685b7589d5d7dd/README.md#build-and-test)
and [test guide](https://github.com/wildcat-finance/v2-protocol/blob/529f2db55d656b89db4b17ecf6685b7589d5d7dd/TESTS.md)
cover setup and focused test runs.

## Documents

| Document | Purpose |
| --- | --- |
| [Audit quote](AUDIT-QUOTE.md) | Start here: size, scope, context, and requested quote terms. |
| [Technical scope](SCOPE.md) | Detailed boundaries, trust assumptions, review priorities, and test instructions. |
| [V2.1-to-V2.5 comparison](V2.1-TO-V2.5.md) | Retained implementation, refactoring, and substantive behavior changes. |
| [Source manifest](evidence/source-manifest.json) | Exact scope paths, source hashes, physical line counts, and artifact identities. |
| [Verification receipt](evidence/verification.json) | Audit-package test results and preparation checks. |
| [Comparison record](evidence/v2.1-to-v2.5-comparison.json) | Per-file normalized counts and source, ABI, storage, and function comparisons. |

The distributed ZIP contains these documents and records. Links to further
technical material open the pinned repository snapshot. The full review scope
includes retained V2.1 code; the comparison helps explain the changes within it.
