# V2.5 audit scope

This package supports audit quoting and a full review of the listed source.
It derives from `release/v2.5` at
`bfe1412141f263ba6b056c60c3f4654a461598dd`, whose `src/` tree is
`9bff1ff9d73c1542a1df2b110f6e5dcd6f6df17a`.
Preparation and verification are dated 2026-10-05.

The audit branch removes out-of-scope implementations and operational material.
Every retained contract source file is byte-for-byte identical to the release
base. Test edits narrow provider matrices and replace excluded provider fixtures;
they do not change the reviewed contracts. Keep the pruning on `audit/v2.5`.
Apply audit fixes separately to the maintained release branch and track their
review delta.

## Source identity and quoting boundary

The [file manifest](evidence/source-manifest.json) is the authoritative path list.
It records source hashes, scope classification, line counts, dependency pins,
and compiled artifact identities. The scope is:

| Material | Boundary |
| --- | --- |
| First-party contract source | All 99 remaining Solidity files under `src/` |
| Installation constructors | `script/common/PreparedInitCodeStorage.sol` |
| Total review source | 100 files; 13,103 nonblank, noncomment physical lines |
| Supporting material | Tests, mocks, shared deployment helpers, technical docs, build configuration, coverage patch, and offline codec reference |
| Third-party dependencies | Pinned `lib/` implementations excluded from a new standalone dependency audit; Wildcat's use and integration assumptions remain in scope |

The line count retains declarations, braces, and imports. It excludes blank
and comment-only lines and is not a logical-statement count. Interfaces and
shared code are included in the total; the manifest provides per-file counts.

The committed audit snapshot supplied to reviewers must be identified by its
full Git SHA, alongside the release base above. The preparation receipt is
bound to file hashes rather than an invented future commit. Record
`git rev-parse HEAD` after committing the package and use that SHA in the quote
request. A branch name alone is not a source freeze.

This is a full review of the listed source, including reused controller,
sanctions, SphereX, and legacy-routing interfaces. It is not limited to the
V2.1 diff. Prior review lineage is indexed in [external reviews](https://github.com/wildcat-finance/v2-protocol/blob/529f2db55d656b89db4b17ecf6685b7589d5d7dd/audits/README.md);
those reports do not cover V2.5 by implication.

## Included behavior

| Area | Review focus |
| --- | --- |
| Markets and accounting | Standard and revolving markets, drawn principal and commitment fees, accrual, reserves, withdrawal-payment carry, rounding, and representation limits |
| Repayment and default | Immutable schedules, inclusive deadlines, historical funding checkpoints, parameter freezes, zero-APR penalty runs, permanent default records, automatic closure, and surplus recovery |
| Withdrawals | Queue ownership, FIFO payment, bounded processing, global and batch capacity, and collection after closure without a hook veto |
| Factories and storage | CREATE2 identity, transient constructor parameters, raw/split/executable creation-code readers, artifact commitments, and installation constructors |
| Hooks and identity | Open, fixed, and periodic terms; APR reduction proposals; composable policy boundaries; borrower/principal transfers and separate hook authority |
| AccessList and shared access control | Membership, provider administration and transfers, factory salts and events, pull/push/validation trust boundaries, cached credentials, and adversarial provider behavior |
| Wrappers and read surfaces | Generation routing, rounding, recipient policy, canonical-wrapper admission, sanctions escrow, permissionless wrapper creation, lens aggregation, and event/ABI semantics |

`LibCompressedInitCode` and its reference tests remain as historical storage
controls. Current deployment selection uses raw or split storage; executable
store decoding and hash validation still warrant review. Review the prepared
installation constructors together with the readers and factory commitments.
`DeployScriptBase` and `LibDeployment` are retained as unchanged support for
those regression tests. The retained `MockArchControllerOwner` is a testnet
helper tested by the suite, outside the production contract quote.

## Exclusions

Role-provider implementation scope is **AccessList, its factory, and the
shared `ManagedRoleProvider` base**, including their interfaces. Merkle,
ERC-20, ERC-721, ERC-1155, ERC-4626-assets, ERC-5192, and ERC-5484 provider
implementations and associated factories/interfaces are removed. Generic
hook/provider interfaces and their defensive integration behavior remain in
scope. An ERC-4626-assets credential provider is distinct from the canonical
ERC-4626 wrapper, which remains fully in scope.

Ceremony UI, deployment plans and histories, deployment orchestration, gas and
optimizer experiments, and superseded audit inventories are omitted. The
[release base](https://github.com/wildcat-finance/v2-protocol/tree/bfe1412141f263ba6b056c60c3f4654a461598dd)
retains their original bytes, including ceremony archives and checksums.
Operational ceremony review and deployment attestation are separate scopes.
The subgraph, SDK, frontend, data gateway, keepers, external sanctions list, and
external SphereX engine are not implementations in this repository's quote.
Their contract-facing assumptions remain relevant to the review.

## Trust and authority

| Actor or dependency | Authority or assumption |
| --- | --- |
| Borrower | Credit risk; may draw assets and use only the configuration powers granted by market and hook terms |
| Lender or arbitrary caller | Untrusted; permissionless entrypoints must not grant discretionary borrower, hook, provider, registry, or recipient authority |
| ArchController owner | Admits factories and controllers and maintains registry policy |
| SphereX admin, operator, and engine | Select and operate transaction checking and registered-sender state |
| Factory or template fee authority | Selects templates and terms for new markets and can push permitted fee-rate changes |
| Hook administrator | Controls mutable hook policy, separately from market borrower and provider administration |
| Provider administrator or provider | Controls credentials and capabilities assigned by the hook configuration |
| Fee recipient | Receives immutable-market-recipient protocol fees after collection |
| Underlying token | Must provide stable supported ERC-20 transfer and metadata behavior |
| Sanctions sentinel and external list | External liveness and classification dependency for sanctions-gated paths |
| Hook, provider, and token callbacks | Potentially adversarial external calls; market, factory, hook, and wrapper reentrancy boundaries must hold |
| Legacy wrapper factory | Trusted generation-routing dependency for markets that do not declare V2.5 floor rounding |

A market permanently trusts its selected hook address, callback flags,
underlying asset, sanctions sentinel, and immutable fee recipient. Listed
assets and external sanctions dependencies must satisfy
[security assumptions](https://github.com/wildcat-finance/v2-protocol/blob/529f2db55d656b89db4b17ecf6685b7589d5d7dd/docs/security/assumptions.md).

State refresh, bounded withdrawal processing, wrapper creation, and execution
of a ready periodic APR reduction are permissionless. Permissionless execution
does not include choosing terms or recipients outside already committed state.

The audit scope includes dormant borrower-account source, but the initial
ceremony must not approve a borrower-account factory without explicitly adding
its runtime authority to the release boundary. See
[known limitations](https://github.com/wildcat-finance/v2-protocol/blob/529f2db55d656b89db4b17ecf6685b7589d5d7dd/docs/security/known-issues.md#dormant-borrower-account-factory-surface).

## Core security properties

The review should independently test these properties rather than treating the
existing suite as proof:

| Domain | Required properties |
| --- | --- |
| Accounting and delinquency | Scaled supply, balances, pending withdrawals, reserved assets, principal, and fee liabilities remain conserved through accrual, donation, repayment, delinquency, expiry, closure, and rounding. Revolving commitment and base APR apply to the intended supply and drawn portions. |
| Withdrawals and time bounds | Batches settle FIFO, never reserve or pay more than attributable underlying, remain executable after closure when funded, and cannot truncate or wrap timestamps, expiries, durations, or scaled amounts. Full-path growth has a bounded operational route. |
| Origination and authority | CREATE2 salts, transient constructor parameters, predicted addresses, borrower identity, registry writes, hook instances, and SphereX configuration cannot be spliced across callers or callbacks. A revert rolls back market, factory, hook, provider, and registry effects. |
| Hooks, providers, and transfers | Every mutable path has the documented administrator, provider, caller, target set, cache behavior, and callback flags. Canonical-wrapper admission is exact, nonzero, market-specific, and recipient-only; it cannot bypass disabled transfers, authorize noncanonical wrappers, or relax policy for market tokens leaving the wrapper. Borrower transfer changes only intended operational identity and cannot transfer hook administration, provider authority, historical debt, or recipient permissions. |
| Wrappers, sanctions, and reads | Deposits, mints, withdrawals, redemptions, sanctions escrow migrations, and generation routing cannot create unbacked shares, widen the registered-wrapper exception, evade the applicable market-token recipient policy, or consume backing owed to holders. Lens pagination and aggregation must not misidentify generations or silently corrupt actionable state. |

Accepted behavior and representation limits are collected in
[known limitations and accepted behavior](https://github.com/wildcat-finance/v2-protocol/blob/529f2db55d656b89db4b17ecf6685b7589d5d7dd/docs/security/known-issues.md). A path
that exceeds those stated effects remains in scope.

## Running and extending the suite

Start with the [README build command](https://github.com/wildcat-finance/v2-protocol/blob/529f2db55d656b89db4b17ecf6685b7589d5d7dd/README.md#build-and-test).
[TESTS.md](https://github.com/wildcat-finance/v2-protocol/blob/529f2db55d656b89db4b17ecf6685b7589d5d7dd/TESTS.md) and the [suite guide](https://github.com/wildcat-finance/v2-protocol/blob/529f2db55d656b89db4b17ecf6685b7589d5d7dd/test/README.md) describe
focused runs, fixture ownership, artifact loading, timestamp handling, and
stateful reference models. New hunting tests belong on concrete suites with
small fixtures; avoid inheriting test entry points. Keep constructor and
factory paths real when their behavior is under review.

The package contains 904 test functions and 11 invariant properties across
85 suites. Forge reports 907 results because it groups the nine market-matrix
properties into one campaign. The three campaigns retain 2,000 runs at depth
30, and fuzz tests retain 1,000 runs.

The release base reported 958 results. This package removes 51 test entry
points devoted to excluded providers: 21 token-provider tests, nine provider
hook-integration tests, 11 Merkle tests, and ten provider-factory tests.
Shared matrices now run the AccessList cases. All three token-backed market
and wrapper regressions remain; a test-only live-balance provider preserves
their real balance reads, interest thresholds, and reentrancy failures.
The receipt lists the excluded and adapted tests explicitly.

## Verification and limits

The [verification receipt](evidence/verification.json) records this package's
actual checks. The compiler, optimizer sequence, metadata settings, call
isolation, submodule pins, and canonical test budgets match the release base.
Default and deployment profiles both use Solidity 0.8.25, Cancun, via IR, and
optimizer runs 1 with the exact Yul sequence in `foundry.toml`.

All 111 retained contract and supporting artifacts match the release in ABI,
creation bytecode, and runtime bytecode under the canonical test build.
This comparison includes all 101 review-scope declarations and ten support
declarations.

The test-only live-balance mock retains an otherwise unused import of Solady's
`MerkleProofLib`. Removing the Merkle provider also removed that compiler
input, changing generated identifiers and the lens optimizer output under
Solidity 0.8.25. Controlled rebuilds isolated the difference: restoring only
that library reproduced the exact release lens hash. Keep this compiler-context
import when reproducing the package's artifacts. Arbitrarily narrowed builds
can emit different bytecode even when contract source is unchanged; production
deployment qualification still belongs to the full release checkout.

Coverage is partial. Use `scripts/coverage.sh` for the temporary SphereX
workaround, and read the [coverage boundary](https://github.com/wildcat-finance/v2-protocol/blob/529f2db55d656b89db4b17ecf6685b7589d5d7dd/test/README.md#coverage-boundary)
before interpreting results. Whole-suite non-via-IR coverage is compiler-blocked;
`--ir-minimum` is not an accurate substitute. Coverage bytecode does not qualify
production runtime sizes. Historical broad coverage and Slither compatibility
results remain in the [release test review](https://github.com/wildcat-finance/v2-protocol/blob/529f2db55d656b89db4b17ecf6685b7589d5d7dd/docs/releases/test-review-2026-10-05.json),
with their original source identities and limits.

Static analysis requires the qualified function-library-resolution Slither
fork described in the suite guide. Parser compatibility is not a completed
security-detector review. Internal testing and preparation do not replace an
independent audit.

Raw canonical test output and the focused coverage records are retained in the
[preparation evidence archive](https://github.com/wildcat-finance/v2-protocol/blob/529f2db55d656b89db4b17ecf6685b7589d5d7dd/docs/releases/v2.5-audit-evidence.zip), with its
[SHA-256 checksum](https://github.com/wildcat-finance/v2-protocol/blob/529f2db55d656b89db4b17ecf6685b7589d5d7dd/docs/releases/v2.5-audit-evidence.zip.sha256). This is preparation evidence,
separate from the deployment ceremony archives retained in the release base.

## Decisions before a production release

The four timing limits marked `TODO FOR MAINNET` in
[`PeriodicTermPolicy`](https://github.com/wildcat-finance/v2-protocol/blob/529f2db55d656b89db4b17ecf6685b7589d5d7dd/src/access/PeriodicTermPolicy.sol) still require
an explicit release decision. Auditors can quote and review their current
values, but changing them creates a source and artifact delta.

The mainnet deployment set, reused runtime addresses/code hashes, and frozen
ceremony still need their own release verification and rehearsal. Dormant
borrower-account registration paths are in source scope; enabling a new
borrower-account factory would add runtime authority requiring separate
review. This audit package does not authorize that deployment decision.

For the quote handoff, supply the committed audit SHA, this scope, the manifest,
and the verification receipt. Reference that exact audit SHA from the release
branch's quote document; do not merge the audit-only deletions into release.
