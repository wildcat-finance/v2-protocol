PREPARATION EVIDENCE ONLY.
headless-fork/ contains local Anvil execution on a Sepolia fork (chain ID 11155111), not live deployment receipts or canonical addresses. No public-chain writes were made. The packet preflight is a read-only live observation. Cold gates on pushed source, real-wallet rehearsal, live activation and downstream adoption are still pending.
