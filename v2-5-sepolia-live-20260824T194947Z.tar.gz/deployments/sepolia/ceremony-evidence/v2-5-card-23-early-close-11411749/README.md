# Sepolia v2.5 card-23 early close

**Release state: deployed and registered; factory retirement deferred.**

## Boundary

- [x] Cards 1-23 are preserved in the unedited checkpoint.
- [x] Card 23 is `register-hooks-factory-revolving` and is `verified`.
- [x] Card 24 is still next: `remove-superseded-controller-factory-01`.
- [x] Cards 24-37 were not executed. At block `11,411,771`, every superseded address was still registered as both a controller factory and a controller.
- [x] ArchController ownership was returned manually after card 23.
- [x] Card 38 was not added to or marked complete in the checkpoint.
- [x] `08-finalize-inventory.sh` was not run as part of this close.
- [x] The terminal halt message is preserved in `CEREMONY_HALT.txt`.
- [x] The run state exported from the halt screen is byte-for-byte identical to the card-23 checkpoint.

## Early-close transaction

```text
Transaction:    0x8ee024703029520726a9be04741daec98bf416e1ffb718ddb34ccbd26b281951
Status:         success (0x1)
Block:          11411749 (0xae2125)
Timestamp:      2026-08-03T17:15:00Z
ArchController: 0xC003f20F2642c76B81e5e1620c6D8cdEE826408f
Old owner:      0xca732651410E915090d7A7D889A1E44eF4575fcE
New owner:      0xa476920af80B587f696734430227869795E2Ea78
```

The transaction called `ArchController.transferOwnership(helper)` directly. It is intentionally outside the 38-card run-state.

The UI then halted as designed because the verified card-1 ownership predicate remains live until card 38 is verified in the run-state. The generic recovery warning cannot detect the out-of-plan transfer; the successful transaction receipt and pinned owner check prove that recovery was already completed. Do not send another ownership transfer.

## Preserved originals

These are byte-for-byte copies. The source files were not edited.

```text
plan-v2-5.json
ceremony-v2-5-eoa.json
run-state-v2-5-card-23-live.json
```

The post-halt UI export is preserved separately as `run-state-v2-5-exported-after-halt.json`. It has the same SHA-256 digest as the checkpoint.

See `SHA256SUMS` for integrity hashes and `manifest.json` for machine-readable identifiers.

## Do not resume this package

- Do not edit the preserved checkpoint.
- Do not mark card 38 complete to account for the manual transfer.
- Do not execute cards 24-37 from this ceremony package.
- Do not run `script/deploy/v2-5/08-finalize-inventory.sh` against this early-close state.
- Preserve the Chrome profile and the origin-scoped storage described in `BROWSER_STATE.md`.

Any later factory-retirement pass should use a newly generated, rehearsed, and independently identified package.
