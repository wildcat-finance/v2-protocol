# Browser state

- [x] Browser: Helium (Chromium-based)
- [x] Profile count: one
- [x] Displayed profile label: `You`
- [x] Tab title: `Wildcat deployment ceremony`
- [x] Exact URL: `http://127.0.0.1:4173/`
- [x] Origin: `http://127.0.0.1:4173`
- [x] Network: Sepolia (`11155111`)
- [x] Mode: EOA
- [x] Pre-close visible progress: `23/38` checks; `TX 24/38` selected next
- [x] Terminal state: `CEREMONY HALTED`
- [x] Connected executor: `0xca732651410E915090d7A7D889A1E44eF4575fcE`
- [x] Ceremony fingerprint: `B939-7712-7C46`
- [x] Ceremony digest: `0xb93977127c460137b84f27c067c4b65c7d6ee7f156a08886547ee392fb8cbd82`
- [x] Plan hash: `0x09440fdfa440ab78690593bdf919fd1fd61f365f0187fb56d143e4d8914009f1`
- [x] Progress storage key: `wildcat-deploy:0xb93977127c460137b84f27c067c4b65c7d6ee7f156a08886547ee392fb8cbd82`
- [x] Halt-screen run state exported at `2026-08-03T17:47:56Z`

The exact tab was left open and its origin-scoped Helium storage was left untouched in place. Browser storage was not read, cleared, or rewritten. The run state was exported through the ceremony UI and is byte-for-byte identical to the unedited card-23 checkpoint. Neither file may be imported back into this retired package to continue cards 24-38.

Do not clear Helium site data for `http://127.0.0.1:4173`, switch this tab to another origin, or reuse this ceremony package as a future retirement ceremony.
